<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">

  <title>PHP index</title>
  <meta name="description" content="The HTML5 Starting Page">
  <meta name="author" content="Stolarz">

  <link rel="stylesheet" href="styles/app.min.css">
</head>

<body>
  <div>Starter page</div>

  <script src="scripts/app.min.js"></script>
</body>
</html>